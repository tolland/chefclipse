## v0.11.0:

* [COOK-1499] - manage tomcat users

## v0.10.4:

* [COOK-1110] - remove deprecated (by upstream) jpackage recipe




